﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HR_Management
{
    public partial class Department : Form
    {
        public Department()
        {
            InitializeComponent();
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button2.Click += new System.EventHandler(this.button2_Click);
            this.button3.Click += new System.EventHandler(this.button3_Click);

        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\kiara\source\repos\HR Management\HR Management\HR.mdf"";Integrated Security=True");

        private void Department_Load(object sender, EventArgs e)
        {
            BindData();
        }

        void BindData()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM deptab", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO deptab (DeptId, DeptName, ManagerId) VALUES (@DeptId, @DeptName, @ManagerId)", con);
                cmd.Parameters.AddWithValue("@DeptId", int.Parse(textBox1.Text));
                cmd.Parameters.AddWithValue("@DeptName", textBox2.Text);
                cmd.Parameters.AddWithValue("@ManagerId", int.Parse(textBox3.Text));
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Added Successfully!");
                BindData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM deptab WHERE DeptId=@DeptId", con);
                cmd.Parameters.AddWithValue("@DeptId", int.Parse(textBox1.Text));
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Deleted Successfully!");
                BindData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
