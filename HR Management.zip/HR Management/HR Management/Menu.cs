﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HR_Management
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Employees_Click(object sender, EventArgs e)
        {
            Employee employeeForm = new Employee();
            employeeForm.Show();
        }

        private void EmployeeInformation_Click(object sender, EventArgs e)
        {
            EmployeeInformation employeeInformationForm = new EmployeeInformation();
            employeeInformationForm.Show();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
           
        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
           
        }

        private void departmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Department departmentForm = new Department();
            departmentForm.Show();
        }
    }
}
