﻿
namespace HR_Management
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            HR_ManagementSystem = new Label();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            Employees = new ToolStripMenuItem();
            EmployeeInformation = new ToolStripMenuItem();
            menuStrip2 = new MenuStrip();
            menuStrip1 = new MenuStrip();
            departmentToolStripMenuItem = new ToolStripMenuItem();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            menuStrip2.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(128, 128, 255);
            panel1.Controls.Add(HR_ManagementSystem);
            panel1.Location = new Point(2, -3);
            panel1.Name = "panel1";
            panel1.Size = new Size(1228, 103);
            panel1.TabIndex = 0;
            // 
            // HR_ManagementSystem
            // 
            HR_ManagementSystem.AutoSize = true;
            HR_ManagementSystem.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            HR_ManagementSystem.Location = new Point(367, 23);
            HR_ManagementSystem.Name = "HR_ManagementSystem";
            HR_ManagementSystem.Size = new Size(490, 54);
            HR_ManagementSystem.TabIndex = 0;
            HR_ManagementSystem.Text = "HR Management System";
            HR_ManagementSystem.Click += HR_ManagementSystem_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Silver;
            panel2.Controls.Add(menuStrip2);
            panel2.Controls.Add(menuStrip1);
            panel2.Location = new Point(5, 96);
            panel2.Name = "panel2";
            panel2.Size = new Size(566, 485);
            panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.download__4_;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(353, 96);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(861, 434);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // Employees
            // 
            Employees.BackColor = Color.FromArgb(255, 255, 128);
            Employees.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Employees.Name = "Employees";
            Employees.Size = new Size(117, 29);
            Employees.Text = "Employees";
            Employees.Click += Employees_Click;
            // 
            // EmployeeInformation
            // 
            EmployeeInformation.BackColor = Color.FromArgb(255, 255, 128);
            EmployeeInformation.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            EmployeeInformation.Name = "EmployeeInformation";
            EmployeeInformation.Size = new Size(216, 29);
            EmployeeInformation.Text = "Employee Information";
            EmployeeInformation.Click += EmployeeInformation_Click;
            // 
            // menuStrip2
            // 
            menuStrip2.ImageScalingSize = new Size(20, 20);
            menuStrip2.Items.AddRange(new ToolStripItem[] { Employees, EmployeeInformation });
            menuStrip2.Location = new Point(0, 36);
            menuStrip2.Name = "menuStrip2";
            menuStrip2.Size = new Size(566, 33);
            menuStrip2.TabIndex = 1;
            menuStrip2.Text = "menuStrip2";
            menuStrip2.ItemClicked += menuStrip2_ItemClicked;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { departmentToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(566, 36);
            menuStrip1.TabIndex = 2;
            menuStrip1.Text = "menuStrip1";
            // 
            // departmentToolStripMenuItem
            // 
            departmentToolStripMenuItem.BackColor = Color.FromArgb(255, 255, 192);
            departmentToolStripMenuItem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            departmentToolStripMenuItem.Name = "departmentToolStripMenuItem";
            departmentToolStripMenuItem.Size = new Size(141, 32);
            departmentToolStripMenuItem.Text = "Department";
            departmentToolStripMenuItem.Click += departmentToolStripMenuItem_Click;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1211, 523);
            Controls.Add(pictureBox1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Menu";
            Text = "Menu";
            Load += Menu_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            menuStrip2.ResumeLayout(false);
            menuStrip2.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
        }

        private void HR_ManagementSystem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Panel panel1;
        private Label HR_ManagementSystem;
        private Panel panel2;
        private PictureBox pictureBox1;
        private MenuStrip menuStrip2;
        private ToolStripMenuItem Employees;
        private ToolStripMenuItem EmployeeInformation;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem departmentToolStripMenuItem;
    }
}